<# if ( data.depth == 0 ) { #>
<a href="#" class="media-menu-item active" data-title="<?php esc_attr_e( 'Mega Menu Content', 'ot_mega-menu' ) ?>"
   data-panel="mega"><?php esc_html_e( 'Mega Menu', 'ot_mega-menu' ) ?></a>
<div class="separator"></div>
<# } #>
